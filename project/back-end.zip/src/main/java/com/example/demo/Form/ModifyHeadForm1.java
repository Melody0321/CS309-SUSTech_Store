package com.example.demo.Form;

import org.springframework.web.multipart.MultipartFile;

public class ModifyHeadForm1 {
    MultipartFile file;

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }
}
