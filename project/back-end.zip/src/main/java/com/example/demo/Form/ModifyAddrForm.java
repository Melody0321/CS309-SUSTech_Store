package com.example.demo.Form;

public class ModifyAddrForm {
    private String address;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
