package com.example.demo.Form;

public class GoodsRestNum {
    long goods_id;
    int rest_num;

    public long getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(long goods_id) {
        this.goods_id = goods_id;
    }

    public int getRest_num() {
        return rest_num;
    }

    public void setRest_num(int rest_num) {
        this.rest_num = rest_num;
    }
}
