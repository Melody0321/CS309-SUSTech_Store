package com.example.demo.Form;

public class GoodsDelete {
    long goods_id;

    public long getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(long goods_id) {
        this.goods_id = goods_id;
    }
}
