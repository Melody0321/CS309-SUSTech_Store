package com.example.demo.dto;


import lombok.Data;

@Data
public class PurchaseGoodsDTO {
    private long goods_id;
    private int number;
    private String password;

}
